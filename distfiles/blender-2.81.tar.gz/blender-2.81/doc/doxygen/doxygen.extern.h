/** \defgroup extern External libraries
 *  \section externabout External libraries
 *  As with \ref intern these libraries are
 *  provided in the Blender codebase. This is
 *  to make building Blender easier. The main
 *  development of these libraries is \b not part
 *  of the normal Blender development process, but
 *  each of the library is developed separately.
 *  Whenever deemed necessary libraries in \c extern/
 *  folder are updated.
 *
 */

/** \defgroup curve_fit Curve Fitting Library
 *  \ingroup extern
 */

/** \defgroup bullet Bullet Physics Library
 *  \ingroup extern
 *  \see \ref bulletdoc
 */
